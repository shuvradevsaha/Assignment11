// Triggers: fail.mod.dotExt
require('./module_invalid_07')
