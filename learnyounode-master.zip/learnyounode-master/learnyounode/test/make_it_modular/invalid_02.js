// Triggers: fail.no_export
require('./module_invalid_01')
