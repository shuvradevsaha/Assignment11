// Triggers: fail.mod.timeout
require('./module_invalid_12')(process.argv[2], process.argv[3], function () {})
