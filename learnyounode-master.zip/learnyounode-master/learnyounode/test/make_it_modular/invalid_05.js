// Triggers: fail.loadError
require('./module_invalid_04')
