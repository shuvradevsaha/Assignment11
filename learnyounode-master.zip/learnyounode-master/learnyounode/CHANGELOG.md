# Change Log

All notable changes to this project will be documented from version 3.5.9 forward
in this file.

<a name="3.5.9"></a>
## [3.5.9](https://github.com/workshopper/learnyounode/compare/v3.5.8...v3.5.9) (2017-02-16)
